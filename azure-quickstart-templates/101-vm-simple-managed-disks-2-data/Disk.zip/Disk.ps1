﻿configuration Disk

{

param ($MachineName)

Import-DscResource -ModuleName PSDesiredStateConfiguration,xDisk,cDisk

Node $MachineName

  {
    xWaitforDisk Disk2
    {
    DiskNumber = 2
    RetryIntervalSec =$RetryIntervalSec
    RetryCount = $RetryCount
    }
    xWaitforDisk Disk3
    {
    DiskNumber = 3
    RetryIntervalSec =$RetryIntervalSec
    RetryCount = $RetryCount
    }
    cDiskNoRestart ADDataDisk2
    {
    DiskNumber = 2
    DriveLetter = "F"
    }
    cDiskNoRestart ADDataDisk3
    {
    DiskNumber = 3
    DriveLetter = "G"
    }
  }
}





    
    