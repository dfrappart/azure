﻿configuration Config

{

param ($MachineName)

Import-DscResource -ModuleName PSDesiredStateConfiguration,xDisk,cDisk

Node $MachineName

  {

    Windowsfeature AD
    {
    Ensure = "Present"
    Name = "AD-Domain-Services"
    }

    Windowsfeature ADRsat
    {
    Ensure = "Present"
    Name = "RSAT-ADDS"
    }

    Windowsfeature DNS
    {
    Ensure = "Present"
    Name = "DNS"
    }

    Windowsfeature DNSRsat
    {
    Ensure = "Present"
    Name = "RSAT-DNS-Server"
    }

    xWaitforDisk Disk2
    {
    DiskNumber = 2
    RetryIntervalSec =$RetryIntervalSec
    RetryCount = $RetryCount
    }

    cDiskNoRestart ADDataDisk
    {
    DiskNumber = 2
    DriveLetter = "F"
    }

  }

}





    
    