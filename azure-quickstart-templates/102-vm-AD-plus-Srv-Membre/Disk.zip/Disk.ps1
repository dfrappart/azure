﻿configuration Disk

{

param ($MachineName)

Import-DscResource -ModuleName PSDesiredStateConfiguration,xDisk,cDisk

Node $MachineName

  {
    xWaitforDisk Disk2
    {
    DiskNumber = 2
    RetryIntervalSec =$RetryIntervalSec
    RetryCount = $RetryCount
    }

    cDiskNoRestart ADDataDisk
    {
    DiskNumber = 2
    DriveLetter = "F"
    }

  }

}





    
    